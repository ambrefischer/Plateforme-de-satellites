package Plateforme.Satellites.SubSystems;

import Mesures.Mesure;
import Plateforme.Satellites.SubSystem;

public class Bitmap extends SubSystem {

    /**
     * Constructeur, reprend les attributs de la super classe SubSystem : name et
     * status
     */
    public Bitmap(String name, boolean status) {
        super(name, status);
    }

    /**
     * Crée une mesure de type Bipmap accompagnée de sa date et la renvoie en format
     * string afin qu'elle puisse être archivée
     */
    protected String createData(int mesureCompt) {
        // Création de la mesure
        Mesure m = new Mesure();

        // Transformation en string
        String mesure = String.valueOf(m.getDate());
        mesure = mesure + " : mesure " + mesureCompt;
        for (double el : m.getStructure()) {
            mesure = mesure + ", " + String.valueOf(el);
        }

        return mesure;
    }

}
