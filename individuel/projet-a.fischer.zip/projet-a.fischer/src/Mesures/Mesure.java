package Mesures;

import java.util.Calendar;
import java.util.Date;

public class Mesure {

    /**
     * contient les données
     */
    private double[] structure;

    /**
     * conserve la date et heure de la mesure
     */
    private Date date;

    /**
     * Constructeur
     */
    public Mesure() {
        // Produit une liste de 10 nombre aléatoire pour créer une bitmap
        double[] map = new double[10];
        for (int i = 0; i < 10; i++) {
            map[i] = Math.random();
        }
        this.structure = map;

        // Récupère l'instant exact de la mesure
        Calendar calendar = Calendar.getInstance();
        this.date = calendar.getTime();
    }

    public double[] getStructure() {
        return this.structure;
    }

    public Date getDate() {
        return this.date;
    }

}
